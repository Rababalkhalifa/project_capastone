﻿import arabic_reshaper
from bidi.algorithm import get_display
 
#...
reshaped_text = arabic_reshaper.reshape(u'اللغة العربية رائعة')
bidi_text = get_display(reshaped_text)

from bidi.algorithm import get_display
import matplotlib.pyplot as plt
import arabic_reshaper
from wordcloud import WordCloud

text = u"انا احب اللغة العربية و حروفها I love English words"
reshaped_text = arabic_reshaper.reshape(text)
artext = get_display(bidi_text)

wordcloud = WordCloud().generate(artext)
wordcloud.to_image()
